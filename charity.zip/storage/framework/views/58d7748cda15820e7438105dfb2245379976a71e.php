<?php
    $r = \Route::current()->getAction();
    $route = (isset($r['as'])) ? $r['as'] : '';
?>

<li class="nav-item mT-30">
    <a class="sidebar-link" href="<?php echo e(url('/admin')); ?>">
        <span class="icon-holder">
            <i class="c-blue-500 ti-home"></i>
        </span>
        <span class="title">Dashboard</span>
    </a>
</li>
<li class="nav-item">
    <a class="sidebar-link" href="<?php echo e(url('/admin/causes')); ?>">
        <span class="icon-holder">
            <i class="c-green-500 ti-flag-alt-2"></i>
        </span>
        <span class="title">Causes Management</span>
    </a>
</li>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('onlyAdmin', auth()->user())): ?>
    <li class="nav-item">
        <a class="sidebar-link" href="<?php echo e(url('/admin/donors')); ?>">
        <span class="icon-holder">
            <i class="c-brown-500 ti-user"></i>
        </span>
            <span class="title">Donors</span>
        </a>
    </li>
<?php endif; ?>

<?php /**PATH D:\projects\www\charity\resources\views/admin/partials/menu.blade.php ENDPATH**/ ?>