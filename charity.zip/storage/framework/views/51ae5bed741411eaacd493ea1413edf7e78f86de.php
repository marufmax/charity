<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4> All causes</h4>
                </div>
                <div class="gaadiex-list">
                    <?php $__empty_1 = true; $__currentLoopData = $causes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cause): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="gaadiex-list-item border-b-1">
                            <img style="max-height: 200px" src="<?php echo e(asset('/images/causes') . '/' . $cause->featured_image); ?>">
                            <div class="gaadiex-list-item-text">
                                <h3><a href="/causes/<?php echo e($cause->slug); ?>"> <?php echo e($cause->title); ?></a></h3>
                                <p>Posted on: <?php echo e($cause->created_at->diffForHumans()); ?></p>
    
                                <p>  <?php echo e($cause->description); ?></p>
                            </div>
                        </div>
                        <hr />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="gaadiex-list-item border-b-1">
                            <p>No causes yet</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php echo $causes->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fronted', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\www\charity\resources\views/causes/index.blade.php ENDPATH**/ ?>