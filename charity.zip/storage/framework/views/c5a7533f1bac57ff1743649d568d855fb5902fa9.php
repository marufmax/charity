<?php $__env->startSection('page-header'); ?>
    Causes <small>Management</small>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="mB-20">
        <a href="<?php echo e(url('/causes')); ?>" class="btn btn-primary">
            Browse Causes
        </a>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('onlyAdmin', auth()->user())): ?>
            <a href="<?php echo e(url('/admin/causes/add')); ?>" class="btn btn-info">
                Add
            </a>
        <?php endif; ?>
    </div>

    <div class="bgc-white bd bdrs-3 p-20 mB-20">
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Title</th>
                <th>Target Amount</th>
                <th>Actions</th>
            </tr>
            </thead>

            <tfoot>
            <tr>
                <th>Title</th>
                <th>Target Amount</th>
                <th>Actions</th>
            </tr>
            </tfoot>

            <tbody>
            <?php $__currentLoopData = $causes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cause): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cause->title); ?></td>
                    <td><?php echo e($cause->target_amount); ?></td>
                    <td>
                        <a href="<?php echo e(url('/causes', $cause->slug)); ?>" class="btn btn-outline-primary">View </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('onlyAdmin', auth()->user())): ?>
                            <form action="<?php echo e(url('/admin/causes/',$cause->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger">Delete</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\www\charity\resources\views/admin/causes/index.blade.php ENDPATH**/ ?>