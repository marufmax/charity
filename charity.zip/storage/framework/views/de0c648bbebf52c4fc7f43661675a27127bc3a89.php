<?php $__env->startSection('page-header'); ?>
    Causes <small>Management</small>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="bgc-white bd bdrs-3 p-20 mB-20">
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>NID</th>
                <th>Location</th>
                <th>Phone No</th>
                <th>Action</th>
            </tr>
            </thead>

            <tfoot>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>NID</th>
                <th>Location</th>
                <th>Phone No</th>
                <th>Action</th>
            </tr>
            </tfoot>

            <tbody>
            <?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($donor->name); ?></td>
                    <td><?php echo e($donor->email); ?></td>
                    <td><?php echo e($donor->nid); ?></td>
                    <td><?php echo e($donor->location); ?></td>
                    <td><?php echo e($donor->phone_no); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.donors.delete', $donor->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\www\charity\resources\views/admin/donors/index.blade.php ENDPATH**/ ?>