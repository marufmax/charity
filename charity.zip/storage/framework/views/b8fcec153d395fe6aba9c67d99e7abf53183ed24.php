<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Laravel Admin by Maruf</title>

<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/global_assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
<!-- Bootstrap -->
<link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/admin/css/bootstrap_limitless.css')); ?>ss.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/admin/css/layout.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/admin/css/components.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/admin/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- /global stylesheets -->

<!-- Core JS files -->
<script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/visualization/d3/d3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/visualization/d3/d3_tooltip.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/forms/styling/switchery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/forms/selects/bootstrap_multiselect.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/plugins/pickers/daterangepicker.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/global_assets/js/demo_pages/dashboard.js')); ?>"></script>
<!-- /theme JS files -->
<?php /**PATH D:\projects\www\charity\resources\views/layouts/includes/head.blade.php ENDPATH**/ ?>