<?php $__env->startSection('page-header'); ?>
    <div class="row">
        Cause <small>Create New</small>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="bgc-white bd bdrs-3 p-20 mB-20">
                <form action="<?php echo e(url('admin/causes/add')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" name="title" id="title" placeholder="Cause Title">
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea rows="8" class="form-control" name="description" id="description"> </textarea>
                    </div>

                    <div class="form-check">
                        <input type="checkbox" name="is_featured"  class="form-check-input" id="is_featured">
                        <label class="form-check-label" for="is_featured">Is featured?</label>
                    </div>

                    <br />

                    <div class="form-group">
                        <label for="target_amount">Target Amount</label>
                        <input type="text" class="form-control" name="target_amount" id="target_amount" placeholder="What is your target amount?">
                    </div>

                    <div class="form-group">
                        <div class="main-img-preview">
                            <img id="preview-image">
                        </div>

                        <label for="target_amount">Featured Image</label>

                        <div class="input-group mb-3">
                            <div class="custom-file">
                                <input type="file" name="featured_image" accept="image/jpeg, image/png" class="custom-file-input" id="inputGroupFile02" onchange="loadFile(event)">
                                <label class="custom-file-label" for="inputGroupFile02">Choose file</label>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const loadFile = (e) => {
            const reader = new FileReader();

            reader.onload = () => {
                const output = document.getElementById('preview-image');
                output.src = reader.result;
            };

            reader.readAsDataURL(e.target.files[0]);
        }
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\www\charity\resources\views/admin/causes/create.blade.php ENDPATH**/ ?>